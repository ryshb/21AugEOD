package com.visa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineorderbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineorderbootApplication.class, args);
	}

}
