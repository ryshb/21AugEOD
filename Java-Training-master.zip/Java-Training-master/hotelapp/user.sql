insert into users (username, email, enabled, name, password) values ("dhruv", "d@visa.com", b'1', "Dhruv", "visa123");
insert into users (username, email, enabled, name, password) values ("banu", "b@visa.com", b'0', "Banu", "123visa");
insert into users (username, email, enabled, name, password) values ("sjack", "jack@visa.com", b'1', "Sam", "1visa23");
insert into users (username, email, enabled, name, password) values ("cap", "c@visa.com", b'0', "Steve", "marvel");
