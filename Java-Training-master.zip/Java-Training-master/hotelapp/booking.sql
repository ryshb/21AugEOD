insert into bookings (beds, checkinDate, checkoutDate, smoking, hotel_id, user_id) values (2, '2019-09-01', '2019-10-15', b'1', 6, 'dhruv');
insert into bookings (beds, checkinDate, checkoutDate, smoking, hotel_id, user_id) values (3, '2017-08-01', '2017-08-15', b'0', 3, 'banu');
insert into bookings (beds, checkinDate, checkoutDate, smoking, hotel_id, user_id) values (5, '2019-08-01', '2019-09-15', b'0', 10, 'cap');
insert into bookings (beds, checkinDate, checkoutDate, smoking, hotel_id, user_id) values (1, '2019-07-01', '2019-07-15', b'1', 5, 'sjack');


insert into bookings (beds, checkinDate, checkoutDate, smoking, hotel_id, user_id) values (1, '2017-09-01', '2017-10-15', b'0', 3, 'dhruv');
insert into bookings (beds, checkinDate, checkoutDate, smoking, hotel_id, user_id) values (2, '2017-08-01', '2017-08-15', b'1', 5, 'banu');
insert into bookings (beds, checkinDate, checkoutDate, smoking, hotel_id, user_id) values (4, '2018-08-01', '2018-09-15', b'1', 1, 'cap');
insert into bookings (beds, checkinDate, checkoutDate, smoking, hotel_id, user_id) values (3, '2019-05-01', '2019-05-15', b'1', 15, 'sjack');


