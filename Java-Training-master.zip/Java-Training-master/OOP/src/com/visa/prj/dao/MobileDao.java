package com.visa.prj.dao;

import com.visa.prj.entity.Mobile;

public interface MobileDao {
	void addMobile(Mobile m); // public and abstract by default (don't put this as it becomes redundant)
}
