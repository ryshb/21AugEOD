package com.visa.prj.web;

public class MessageConfig {

}
